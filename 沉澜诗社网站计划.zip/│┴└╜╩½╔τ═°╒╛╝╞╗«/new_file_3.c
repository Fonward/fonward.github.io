#include <stdio.h>
int main() {
   printf("来点狠的！！！");
   return 0;
}