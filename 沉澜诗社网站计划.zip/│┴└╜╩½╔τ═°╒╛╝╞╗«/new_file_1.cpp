#include <iostream>
using namespace std;
int main() {
   cout << "我就是回日！！！";
   return 0;
}